package com.example.demo.controller;

import com.example.demo.model.Login;
import com.example.demo.service.Loginservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = {"http://localhost:3000"})
public class Logincontrol {
    @Autowired
    Loginservice service;
    @PostMapping( value = "/save" ,consumes = MediaType.APPLICATION_JSON_VALUE ,produces = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity<Login> print(@RequestBody Login log)
    {
        service.store(log);
        return new ResponseEntity<Login>(log, HttpStatus.CREATED);
    }


    @GetMapping( value = "/Login" ,produces = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity<List<Login>> getStds()
    {
        List<Login> list=service.getUsers();
        return new ResponseEntity<List<Login>>(list,HttpStatus.CREATED);
    }
    @GetMapping( value = "/Login/{id}" ,produces = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity<Login> getStd(@PathVariable("id") int id)
    {
        Login log=service.getUser(id);
        return new ResponseEntity<Login>(log,HttpStatus.CREATED);
    }

    @PutMapping( value = "/Login" ,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Login> updateStd(@RequestBody Login log)
    {
        service.store(log);
        return new ResponseEntity<Login>(log,HttpStatus.CREATED);
    }

    @DeleteMapping( value = "/delete/{id}" ,consumes = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity<String> deleteStudent(@PathVariable("id") int id)
    {
        service.deletelog(id);
        return new ResponseEntity<String>("recored deleted",HttpStatus.CREATED);
    }


}
