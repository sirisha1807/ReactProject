package com.example.demo.service;

import com.example.demo.model.Login;
import com.example.demo.repo.LoginRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Loginservice {
    @Autowired
    LoginRepo repo;

    public void store(Login log) {
        repo.save(log);
    }
    public List<Login> getUsers() {

        List<Login> list=repo.findAll();

        return list;
    }

    public Login getUser(int id) {

        Login log=repo.findById(id).orElse(new Login());

        return log;
    }

    public void deletelog(int id) {
        repo.deleteById(id);
    }
}
