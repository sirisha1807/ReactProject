import React, { Component } from "react";
import './About.css';
 class About extends Component{
    render(){
        return(
            <div className="about">
                <h1 className="aa"> About</h1>
                <br />
                <br /> 
                <p>Stationery Hut, an e-commerce shopping complex for personal, institutional and office stationery, is a division of Emarketz India Pvt. Ltd. </p>
                    <p >This virtual stationery market endeavours to bring a wide variety of products at discounted rates.</p> 
                    <p> the company has shaped a broad mount of satisfied consumers from Schools, Universities, Hospitals, Banks, Corporates, NGO's and many households.</p>
    
            </div>
        )
    }
}

export default About;